# steamdt-batch-client

Minimal, production‑minded Go client for **SteamDT CS2 Batch Price API** that keeps **all platform prices** returned for each `marketHashName`. It emits one normalized `Quote` per `(symbol, platform, side)` where side is **sell** (and **bid** if enabled).

- **Endpoint:** `POST https://open.steamdt.com/open/cs2/v1/price/batch`  
- **Auth:** `Authorization: Bearer <YOUR_API_KEY>`  
- **Docs:** see SteamDT Open Platform docs for the batch endpoint and auth header.

## Quickstart

```bash
# Requires Go 1.22+
git clone <this folder>  # or unzip the file I provided
cd steamdt-batch-client

# Initialize / download deps
go mod download

# Set your API key
export STEAMDT_API_KEY="YOUR_KEY"

# Run a single fetch for one or more marketHashNames (comma‑separated)
go run ./cmd/steamdt-client   -symbols "★ Karambit | Doppler (Factory New),AK-47 | Redline (Field-Tested)"   -include-bids=true   -pretty=true
```

Write output to a file and poll every 60s:

```bash
go run ./cmd/steamdt-client   -symbols "★ Karambit | Doppler (Factory New)"   -out prices.json   -interval 60
```

### Output shape

```json
{
  "quotes": [
    {
      "symbol": "★ Karambit | Doppler (Factory New)",
      "price": "64231.42",
      "currency": "CNY",
      "source": "SteamDT:Steam:sell",
      "received_at": "2025-09-06T12:34:56Z"
    },
    {
      "symbol": "★ Karambit | Doppler (Factory New)",
      "price": "64200.01",
      "currency": "CNY",
      "source": "SteamDT:Steam:bid",
      "received_at": "2025-09-06T12:34:56Z"
    }
  ]
}
```

> We **keep all platform prices**: each listing yields one `:sell` quote and, if `-include-bids` is true and a bid is present, one `:bid` quote. You can feed these quotes into your aggregator later.

## Configuration

- `STEAMDT_API_KEY` or `-api-key`: your SteamDT Open Platform API key (Bearer token).  
- `-symbols`: comma-separated list of `marketHashName` strings.  
- `-endpoint`: override API endpoint (defaults to the documented batch URL).  
- `-include-bids`: include `biddingPrice` as separate quotes.  
- `-currency`: tag quotes (default **CNY**; docs don’t specify a currency, so keep this configurable).  
- `-pretty`: pretty-print JSON.  
- `-out`: write to file instead of stdout.  
- `-interval`: if >0, poll every N seconds.

## Internals

- `internal/provider/steamdt`: SteamDT adapter using `json.Decoder.UseNumber()` and `shopspring/decimal` to avoid float rounding.
- `internal/provider/basehttp`: resilient HTTP client (timeouts, rate limiting, circuit breaker).
- `internal/provider/provider.go`: `Quote` type + `Provider` interface for reuse in your aggregator.

## Rate limits

Docs list `/open/cs2/v1/price/batch` at **1 request per minute**. The client ships with a default token bucket limiter configured at 1 req/min. Adjust if your plan differs.

---

**License:** MIT
