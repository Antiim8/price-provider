// Package steamdt implements the SteamDT CS2 batch price adapter.
// Docs: https://doc.steamdt.com/278832831e0  (batch)
// Auth header: Authorization: Bearer <API_KEY>  (https://doc.steamdt.com/)
package steamdt

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sort"
	"strings"
	"time"

	"github.com/shopspring/decimal"

	"steamdt_batch_client/internal/provider"
	"steamdt_batch_client/internal/provider/basehttp"
)

type Config struct {
	Name        string            // display name (e.g., "SteamDT")
	URL         string            // endpoint, default: https://open.steamdt.com/open/cs2/v1/price/batch
	Method      string            // default POST
	Headers     map[string]string // extra headers (Content-Type set automatically)
	Currency    string            // e.g., "CNY" (default) or "USD"
	SymbolMap   map[string]string // aggregator symbol -> provider marketHashName
	IncludeBids bool              // if true, also emit bid prices (biddingPrice)
}

type Provider struct {
	cfg    Config
	client *basehttp.Client
}

func New(cfg Config, hc *basehttp.Client) (*Provider, error) {
	if cfg.Name == "" { cfg.Name = "SteamDT" }
	if cfg.URL == "" { cfg.URL = "https://open.steamdt.com/open/cs2/v1/price/batch" }
	if cfg.Method == "" { cfg.Method = http.MethodPost }
	if cfg.Currency == "" { cfg.Currency = "CNY" } // The docs don't specify; make it configurable.
	return &Provider{cfg: cfg, client: hc}, nil
}

func (p *Provider) Name() string { return p.cfg.Name }

func (p *Provider) Fetch(ctx context.Context, symbols []string) ([]provider.Quote, error) {
	// map requested symbols -> provider keys
	var provKeys []string
	keyByAgg := make(map[string]string, len(symbols))
	for _, s := range symbols {
		key := s
		if v := p.cfg.SymbolMap[s]; v != "" { key = v }
		keyByAgg[s] = key
		provKeys = append(provKeys, key)
	}
	payload := map[string]any{"marketHashNames": provKeys}
	body, _ := json.Marshal(payload)

	req, err := http.NewRequestWithContext(ctx, p.cfg.Method, p.cfg.URL, bytes.NewReader(body))
	if err != nil { return nil, err }
	req.Header.Set("Content-Type", "application/json")
	for k, v := range p.cfg.Headers { req.Header.Set(k, v) }

	resp, err := p.client.Do(ctx, req)
	if err != nil { return nil, err }
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<10))
		return nil, fmt.Errorf("%s %s -> %d: %s", p.cfg.Method, p.cfg.URL, resp.StatusCode, string(b))
	}

	dec := json.NewDecoder(resp.Body)
	dec.UseNumber()
	var api apiResponse
	if err := dec.Decode(&api); err != nil { return nil, fmt.Errorf("decode: %w", err) }

	// if the API indicates an error and no data, surface it
	if !api.Success && (api.ErrorCode != 0 || strings.TrimSpace(api.ErrorMsg) != "") && len(api.Data) == 0 {
		return nil, fmt.Errorf("provider error: code=%d msg=%q", api.ErrorCode, api.ErrorMsg)
	}

	// index results by marketHashName for quick lookup
	byMarket := make(map[string]entry, len(api.Data))
	for _, e := range api.Data { byMarket[e.MarketHashName] = e }

	now := time.Now().UTC()
	out := make([]provider.Quote, 0, len(symbols)*4)

	for _, aggSym := range symbols {
		provKey := keyByAgg[aggSym]
		if e, ok := byMarket[provKey]; ok {
			// we keep ALL prices provided: each listing becomes one or two quotes (sell + optional bid)
			cs := collectCandidates(e.DataList, now)
			for _, c := range cs {
				out = append(out, provider.Quote{
					Symbol:     aggSym,
					Price:      c.sell,
					Currency:   p.cfg.Currency,
					Source:     fmt.Sprintf("%s:%s:sell", p.cfg.Name, c.platform),
					ReceivedAt: c.ts,
				})
				if p.cfg.IncludeBids && c.bid.GreaterThan(decimal.Zero) {
					out = append(out, provider.Quote{
						Symbol:     aggSym,
						Price:      c.bid,
						Currency:   p.cfg.Currency,
						Source:     fmt.Sprintf("%s:%s:bid", p.cfg.Name, c.platform),
						ReceivedAt: c.ts,
					})
				}
			}
		}
	}

	return out, nil
}

type entry struct {
	MarketHashName string    `json:"marketHashName"`
	DataList       []listing `json:"dataList"`
}

type listing struct {
	Platform       string      `json:"platform"`
	PlatformItemID string      `json:"platformItemId"`
	SellPrice      json.Number `json:"sellPrice"`
	SellCount      int         `json:"sellCount"`
	BiddingPrice   json.Number `json:"biddingPrice"`
	BiddingCount   int         `json:"biddingCount"`
	UpdateTime     int64       `json:"updateTime"`
}

type apiResponse struct {
	Success     bool    `json:"success"`
	Data        []entry `json:"data"`
	ErrorCode   int     `json:"errorCode"`
	ErrorMsg    string  `json:"errorMsg"`
	ErrorData   any     `json:"errorData"`
	ErrorCodeStr string `json:"errorCodeStr"`
}

type candidate struct {
	platform string
	sell     decimal.Decimal
	bid      decimal.Decimal
	ts       time.Time
}

func collectCandidates(list []listing, now time.Time) []candidate {
	cs := make([]candidate, 0, len(list))
	for _, d := range list {
		sel, _ := decimalFromNumber(d.SellPrice)
		bid, _ := decimalFromNumber(d.BiddingPrice)
		if sel.LessThanOrEqual(decimal.Zero) && bid.LessThanOrEqual(decimal.Zero) {
			continue
		}
		ts := parseEpochMaybeMillis(d.UpdateTime, now)
		cs = append(cs, candidate{platform: d.Platform, sell: sel, bid: bid, ts: ts})
	}
	// stable order for reproducibility
	sort.Slice(cs, func(i, j int) bool {
		if cs[i].platform == cs[j].platform {
			return cs[i].ts.Before(cs[j].ts)
		}
		return cs[i].platform < cs[j].platform
	})
	return cs
}

func decimalFromNumber(n json.Number) (decimal.Decimal, error) {
	s := n.String()
	if s == "" { return decimal.Zero, fmt.Errorf("empty number") }
	return decimal.NewFromString(s)
}

func parseEpochMaybeMillis(v int64, fallback time.Time) time.Time {
	if v <= 0 { return fallback }
	if v > 1_000_000_000_000 { // ms
		return time.UnixMilli(v).UTC()
	}
	return time.Unix(v, 0).UTC()
}
