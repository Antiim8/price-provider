// Package basehttp provides a resilient HTTP client with timeouts, optional
// rate limiting and circuit breaking.
package basehttp

import (
	"context"
	"errors"
	"io"
	"net"
	"net/http"
	"time"

	"github.com/sony/gobreaker"
	"golang.org/x/time/rate"
)

type Client struct {
	HTTP           *http.Client
	Limiter        *rate.Limiter
	Breaker        *gobreaker.CircuitBreaker
	DefaultHeaders map[string]string
	UserAgent      string
}

type Option func(*Client)

func WithLimiter(l *rate.Limiter) Option { return func(c *Client) { c.Limiter = l } }
func WithBreaker(b *gobreaker.CircuitBreaker) Option { return func(c *Client) { c.Breaker = b } }
func WithDefaultHeaders(h map[string]string) Option { return func(c *Client) { c.DefaultHeaders = h } }
func WithUserAgent(ua string) Option { return func(c *Client) { c.UserAgent = ua } }

func New(timeout time.Duration, opts ...Option) *Client {
	transport := &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		DialContext: (&net.Dialer{
			Timeout:   3 * time.Second,
			KeepAlive: 30 * time.Second,
		}).DialContext,
		MaxIdleConns:          100,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   3 * time.Second,
		ExpectContinueTimeout: 1 * time.Second,
	}
	httpClient := &http.Client{Timeout: timeout, Transport: transport}
	c := &Client{HTTP: httpClient, UserAgent: "steamdt-batch-client/1.0"}
	for _, o := range opts { o(c) }
	return c
}

// Do applies rate limiting and circuit breaking. Caller must close resp.Body.
func (c *Client) Do(ctx context.Context, req *http.Request) (*http.Response, error) {
	if c.UserAgent != "" && req.Header.Get("User-Agent") == "" {
		req.Header.Set("User-Agent", c.UserAgent)
	}
	for k, v := range c.DefaultHeaders {
		if req.Header.Get(k) == "" { req.Header.Set(k, v) }
	}
	if c.Limiter != nil {
		if err := c.Limiter.Wait(ctx); err != nil { return nil, err }
	}
	call := func() (*http.Response, error) { return c.HTTP.Do(req) }
	if c.Breaker != nil {
		v, err := c.Breaker.Execute(func() (interface{}, error) {
			resp, err := call()
			if err == nil && resp != nil && resp.StatusCode >= 500 {
				_, _ = io.Copy(io.Discard, resp.Body)
				_ = resp.Body.Close()
				return nil, errors.New(resp.Status)
			}
			return resp, err
		})
		if err != nil { return nil, err }
		return v.(*http.Response), nil
	}
	return call()
}
