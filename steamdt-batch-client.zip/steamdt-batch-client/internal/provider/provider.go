// Package provider defines the normalized Quote shape and Provider interface.
package provider

import (
	"context"
	"time"

	"github.com/shopspring/decimal"
)

// Quote is the normalized shape that every adapter returns.
// We keep one Quote per (symbol, source) — so if a provider offers multiple
// platform prices, we emit multiple Quotes with distinct Source names.
type Quote struct {
	Symbol     string          `json:"symbol"`
	Price      decimal.Decimal `json:"price"`
	Currency   string          `json:"currency"`
	Source     string          `json:"source"`
	ReceivedAt time.Time       `json:"received_at"`
}

type Provider interface {
	Name() string
	// Fetch returns zero or more quotes for the requested symbols.
	// Missing symbols are simply omitted — the call should not fail the whole batch.
	Fetch(ctx context.Context, symbols []string) ([]Quote, error)
}
