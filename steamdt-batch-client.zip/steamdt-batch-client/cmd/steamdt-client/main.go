package main

import (
	"bytes"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"github.com/sony/gobreaker"
	"golang.org/x/time/rate"

	"steamdt_batch_client/internal/provider"
	"steamdt_batch_client/internal/provider/basehttp"
	"steamdt_batch_client/internal/provider/steamdt"
)

type output struct {
	Quotes []provider.Quote `json:"quotes"`
}

func main() {
	var symbolsCSV string
	var apiKey string
	var endpoint string
	var includeBids bool
	var currency string
	var pretty bool
	var outFile string
	var interval int

	flag.StringVar(&symbolsCSV, "symbols", getEnv("SYMBOLS", "★ Karambit | Doppler (Factory New)"), "comma-separated marketHashNames to fetch")
	flag.StringVar(&apiKey, "api-key", os.Getenv("STEAMDT_API_KEY"), "SteamDT API key (or set STEAMDT_API_KEY)")
	flag.StringVar(&endpoint, "endpoint", getEnv("STEAMDT_ENDPOINT", "https://open.steamdt.com/open/cs2/v1/price/batch"), "SteamDT batch price endpoint")
	flag.BoolVar(&includeBids, "include-bids", getEnvBool("INCLUDE_BIDS", true), "Emit biddingPrice quotes in addition to sellPrice")
	flag.StringVar(&currency, "currency", getEnv("CURRENCY", "CNY"), "Currency code to tag quotes with (docs don't specify; default CNY)")
	flag.BoolVar(&pretty, "pretty", getEnvBool("PRETTY", true), "Pretty-print JSON")
	flag.StringVar(&outFile, "out", os.Getenv("OUT"), "Write JSON to this file instead of stdout (optional)")
	flag.IntVar(&interval, "interval", getEnvInt("INTERVAL_SEC", 0), "If >0, poll every N seconds; otherwise run once and exit")
	flag.Parse()

	if apiKey == "" {
		log.Fatal("missing API key: set -api-key or STEAMDT_API_KEY")
	}

	symbols := splitCSV(symbolsCSV)
	if len(symbols) == 0 {
		log.Fatal("no symbols provided")
	}

	httpBase := basehttp.New(5*time.Second,
		basehttp.WithUserAgent("steamdt-batch-client/1.0"),
		basehttp.WithLimiter(rate.NewLimiter(rate.Every(time.Minute), 1)), // respect 1 req/min for batch per docs
		basehttp.WithBreaker(gobreaker.NewCircuitBreaker(gobreaker.Settings{
			Name:        "steamdt",
			MaxRequests: 1,
			Interval:    30 * time.Second,
			Timeout:     20 * time.Second,
		})),
	)

	prov, err := steamdt.New(steamdt.Config{
		Name:        "SteamDT",
		URL:         endpoint,
		Method:      http.MethodPost,
		Headers:     map[string]string{"Authorization": "Bearer " + apiKey},
		Currency:    currency,
		SymbolMap:   map[string]string{},
		IncludeBids: includeBids,
	}, httpBase)
	if err != nil { log.Fatalf("provider: %v", err) }

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	runOnce := func() error {
		quotes, err := prov.Fetch(ctx, symbols)
		if err != nil { return err }
		out := output{Quotes: quotes}
		var b []byte
		if pretty { b, _ = json.MarshalIndent(out, "", "  ") } else { b, _ = json.Marshal(out) }
		if outFile != "" {
			return os.WriteFile(outFile, b, 0o644)
		}
		os.Stdout.Write(append(b, '\n'))
		return nil
	}

	if interval <= 0 {
		if err := runOnce(); err != nil { log.Fatalf("fetch: %v", err) }
		return
	}

	ticker := time.NewTicker(time.Duration(interval) * time.Second)
	defer ticker.Stop()
	for {
		if err := runOnce(); err != nil {
			log.Printf("fetch error: %v", err)
		}
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			// loop
		}
	}
}

func splitCSV(s string) []string {
	parts := strings.Split(s, ",")
	var out []string
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" { out = append(out, p) }
	}
	return out
}

func getEnv(key, def string) string { if v := os.Getenv(key); v != "" { return v }; return def }
func getEnvInt(key string, def int) int {
	if v := os.Getenv(key); v != "" {
		var x int
		_, _ = fmt.Sscanf(v, "%d", &x)
		if x != 0 { return x }
	}
	return def
}
func getEnvBool(key string, def bool) bool {
	if v := os.Getenv(key); v != "" {
		switch strings.ToLower(v) {
		case "1","true","yes","y": return true
		case "0","false","no","n": return false
		}
	}
	return def
}
